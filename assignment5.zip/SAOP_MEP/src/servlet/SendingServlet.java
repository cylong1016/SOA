package servlet;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;

import javax.activation.DataHandler;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
/**
 * SOAP消息的发送端Servlet
 */
@SuppressWarnings("serial")
public class SendingServlet extends HttpServlet
{
	ServletContext servletContext;
	// 发送消息的链接
	private SOAPConnection conn;

	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		servletContext = config.getServletContext();
		try
		{
			// 创建一个SOAP链接工厂
			SOAPConnectionFactory factory = SOAPConnectionFactory.newInstance();
			// 创建一个SOAP链接
			conn = factory.createConnection();
		} catch (SOAPException e)
		{
			System.out.println("创建SOAP链接失败!");
			e.printStackTrace();
		}
	}

	/**
	 * SOAP消息格式
	 *
		<?xml version="1.0"?>
		<soap:Envelope
	　　		xmlns:soap="http://www.w3.org/2001/12/soap-envelope"
	　　		soap:encodingStyle="http://www.w3.org/2001/12/soap-encoding">
	　　		<soap:Header>
				...
			</soap:Header>
			<soap:Body>
				...
				<soap:Fault>
					...
				</soap:Fault>
			</soap:Body>
		</soap:Envelope>
		[附件信息]
	 *
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		// 1.创建消息工厂
		// 2.创建soap消息reqMsg

		// 3.创建soap消息的部分reqMsgpart
		// 3.1.创建sope信封envelope，要开始写信了，哈哈
		// 3.2.写header
		// 3.3.写body
		// 3.4.向body中添加元素，即要传递的数据

		// 4.创建reqMsg的附件attachmentpart，

		// 5.创建SOAP消息的目标对象（服务端点endPoint），即消息发给谁

		// 6.发送SOAP消息，并接收返回信息
		try
		{
			// 1.
			MessageFactory factory = MessageFactory.newInstance();
			// 2.
			SOAPMessage reqMsg = factory.createMessage();
			// 3.
			SOAPPart part = reqMsg.getSOAPPart();
			// 3.1
			SOAPEnvelope envelope = part.getEnvelope();
			// envelope.setPrefix("soap");	// 默认是SOAP-ENV
			// 3.2
			// SOAPHeader header = envelope.getHeader();
			// 3.3
			SOAPBody body = envelope.getBody();
			// 3.4
			SOAPBodyElement bodyElement = body.addBodyElement(envelope.createName("sayHello", "zhaoql", "http://zhaoql.java.cn"));
			bodyElement.addChildElement(envelope.createName("username", "zhaoql", "http://zhaoql.java.cn")).addTextNode("清玲");
			// 4.
			String reqBaseUrl = getReqBaseUrl(request);
			// 将项目根目录下的index.jsp作为附件发送
			AttachmentPart attachment = reqMsg.createAttachmentPart(new DataHandler(new URL(reqBaseUrl + "/index.jsp")));
			attachment.setContentType("text/html");
			reqMsg.addAttachmentPart(attachment);
			// 5.（将消息发送给一个Servlet）
			URL endPoint = new URL(reqBaseUrl + "/ReceivingServlet");
			// 6.
			SOAPMessage respMsg = conn.call(reqMsg, endPoint);
			
			// 将发送的消息、返回的消息	写入到文件中
			writeMsgToFile(reqMsg, respMsg);
			out.print("success!");
		} catch (SOAPException e)
		{
			e.printStackTrace();
			out.print("error!\n" + e.getMessage());
		}
		out.flush();
		out.close();
	}
	/**
	 * 将发送的消息、返回的消息	写入到文件中
	 * @param reqMsg	请求的消息
	 * @param respMsg	响应的消息
	 */
	private void writeMsgToFile(SOAPMessage reqMsg, SOAPMessage respMsg) throws SOAPException, IOException
	{
		FileOutputStream fos_1 = new FileOutputStream("F:/reqeust.txt");
		reqMsg.writeTo(fos_1);
		fos_1.close();
		
		FileOutputStream fos_2 = new FileOutputStream("F:/response.txt");
		respMsg.writeTo(fos_2);
		fos_2.close();
		
		System.out.println("\n=====================请求的消息 : ");
		reqMsg.writeTo(System.out);
		
		System.out.println("\n=====================接收的消息 : ");
		respMsg.writeTo(System.out);
	}

	/**
	 * 返回请示的URL前面部分，如
	 * 请求URL：	http://localhost:8080/[ProjectName]/[Module]/[MyServlet]
	 * 返回：		http://localhost:8080/[ProjectName]
	 */
	private String getReqBaseUrl(HttpServletRequest req)
	{
		StringBuffer urlSB=new StringBuffer();
        urlSB.append(req.getScheme())
        	.append("://")
        	.append(req.getServerName())
        	.append(":")
        	.append(req.getServerPort())
        	.append(req.getContextPath());
        return urlSB.toString();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}

	public SendingServlet()
	{
		super();
	}
}